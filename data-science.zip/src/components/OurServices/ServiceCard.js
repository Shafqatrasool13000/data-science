import { Stack, Grid, Container } from '@mui/material';
import { Box } from '@mui/system';
import React from 'react';

import './ServiceCard.css'
const ServiceCard = () => {
    
    return(
<Container>
    
        
            </Container>
            ) 
    
};

export default ServiceCard;
