import React from 'react';
import './DataProcessing.css'


const SelectMerge2 = () => {
  return <div>
      <select className='select2' id="country" name="country">
      <option value="australia">How</option>
      <option value="canada">Left on</option>
      <option value="usa">Right</option>
    </select>
  </div>;
};

export default SelectMerge2;
