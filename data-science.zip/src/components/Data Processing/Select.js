import * as React from 'react';

import './Select.css'

export default function Select() {
 

  return (
   
    <select id="country" name="country">
      <option value="australia">How</option>
      <option value="canada">Left on</option>
      <option value="usa">Right</option>
    </select>
    
  );
}
