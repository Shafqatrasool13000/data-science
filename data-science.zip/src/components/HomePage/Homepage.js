// import React from 'react';
// import AboutUs from './AboutUs/AboutUs';
// import ContactUs from '../Contact Us/ContactUs ';
// import Header from '../Header/Header';
// import OurServices from '../OurServices/OurServices';
// import UseCases from '../UseCases/UseCases';
// import DataProcessing from '../Data Processing/DataProcessing';
// import SpecificKey from '../SpecificKeyVariables/SpecificKey';


// const Homepage = () => {
//     return <>
//         <Header />
//         <DataProcessing/>
//         <SpecificKey/>
//         <AboutUs />
//         <OurServices />
//         <UseCases />
//         <ContactUs />
//     </>;
// };

// export default Homepage;

