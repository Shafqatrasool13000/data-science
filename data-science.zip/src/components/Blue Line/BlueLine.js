import './BlueLine.css'

const BlueLine = () => {
  return <p  class="below-line"></p>
};

export default BlueLine;
